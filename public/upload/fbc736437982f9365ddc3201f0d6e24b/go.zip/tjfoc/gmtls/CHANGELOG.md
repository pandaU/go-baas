# Change Log

### v1.2 版本更新(Feb 27, 2019)

- 国密证书完全兼容标准

需引用 github.com/tjfoc/sm 1.2版本